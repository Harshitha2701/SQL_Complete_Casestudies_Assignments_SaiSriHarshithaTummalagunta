-----------------Assignment 1 -----------------
create database Harshitha;

use Harshitha;

CREATE TABLE Salesman (
    SalesmanId INT,
    Name VARCHAR(255),
    Commission DECIMAL(10, 2),
    City VARCHAR(255),
    Age INT
);


INSERT INTO Salesman (SalesmanId, Name, Commission, City, Age)
VALUES
    (101, 'Joe', 50, 'California', 17),
    (102, 'Simon', 75, 'Texas', 25),
    (103, 'Jessie', 105, 'Florida', 35),
    (104, 'Danny', 100, 'Texas', 22),
    (105, 'Lia', 65, 'New Jersey', 30);

select * from Salesman;

CREATE TABLE Customer (
    SalesmanId INT,
    CustomerId INT,
    CustomerName VARCHAR(255),
    PurchaseAmount INT
    );


INSERT INTO Customer (SalesmanId, CustomerId, CustomerName, PurchaseAmount)
VALUES
    (101, 2345, 'Andrew', 550),
    (103, 1575, 'Lucky', 4500),
    (104, 2345, 'Andrew', 4000),
    (107, 3747, 'Remona', 2700),
    (110, 4004, 'Julia', 4545);
    
select * from Customer;

CREATE TABLE Orders (
OrderId int, 
CustomerId int, 
SalesmanId int, 
Orderdate Date, 
Amount MONEY )

INSERT INTO Orders Values 
(5001,2345,101,'2021-07-01',550),
(5003,1234,105,'2022-02-15',1500)

select * from orders;

-- 1. Insert a new record in your Orders table.

insert into Orders VALUES
(5002,3254,103,'2021-12-25',660);

--2. Add Primary key constraint for SalesmanId column in Salesman table.
alter table Salesman
add constraint sal_rk primary key(salesmanid);

--Add default constraint for City column in Salesman table. 
ALTER TABLE Salesman
ADD CONSTRAINT df_City DEFAULT 'Maxico' FOR City;

--Add Foreign key constraint for SalesmanId column in Customer table.
alter table Salesman
add CONSTRAINT sal_fn FOREIGN KEY(salesmanid) REFERENCES Salesman(salesmanid);

--Add not null constraint in Customer_name column for the Customer table.
ALTER TABLE Customer
ADD column Customer_name  not null;

-- 3. Fetch the data where the Customer�s name is ending with �N� also get the purchase amount value greater than 500.
select * from Customer;

select customername.purchaseamount
from Customer
where customername like "%N" and purchaseamount>500;

--4. Using SET operators, retrieve the first result with unique SalesmanId values from two tables, 
select salesmanid from Salesman
UNION
select salesmanid from Customer;

--and the other result containing SalesmanId with duplicates from two tables.
select salesmanid from Salesman
UNION all
select salesmanid from Customer;

--5. Display the below columns which has the matching data.
--Orderdate, Salesman Name, Customer Name, Commission, and City which has the
-- range of Purchase Amount between 500 to 1500.
select * from Salesman;
select o.Orderdate,s.name,c.customername ,s.Commission,s.city
from Salesman s 
join customer c 
	on s.SalesmanId=c.SalesmanId
join Orders o
	on s.SalesmanId=o.SalesmanId
where c.PurchaseAmount between 500 and 1500;

--6. Using right join fetch all the results from Salesman and Orders table.
select * from Salesman
right join Orders
on Salesman.SalesmanId=Orders.SalesmanId;
