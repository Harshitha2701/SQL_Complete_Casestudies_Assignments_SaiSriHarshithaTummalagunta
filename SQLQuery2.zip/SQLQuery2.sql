 ----------------------- Assignment - 2 (Sai Sri Harshitha Tummalagunta)  -----------------------------


 ----- Steps I Did while loading the jomato dataset  are:
 ----- 1.  Right click on my database named saisriharshitha
 ------2. click on Tasks 
 ------3. click on Import Flat File and then you can browse and upload the dataset which is in xlsx or csv format 
 ------4. Preview data and if you want to make any changes like datatypes etc you can do it here 
 ------5. Summary and then click on Finish 

create database  saisriharshitha;
use saisriharshitha; 

select * from jomato;

-- 1. Create a user-defined functions to stuff the Chicken into �Quick Bites�. Eg: �Quick
-- Chicken Bites�.

CREATE FUNCTION dbo.StuffChickenIntoQuickBites (@str VARCHAR(255))
RETURNS varchar(255)
AS
BEGIN
    DECLARE @str VARCHAR(255)
    SET @str = REPLACE(@str, 'Quick', 'Quick Chicken')
    RETURN @str
END


SELECT dbo.StuffChickenIntoQuickBites('Quick Bites') AS Result;


-- 2. Use the function to display the restaurant name and cuisine type which has the
-- maximum number of rating.
select resturantname,cuisinsType
from jomato 
where No.of.Rating=(select max(No.of.Rating) from jomato);

-- 3. Create a Rating Status column to display the rating as �Excellent� if it has more the 4
-- start rating, �Good� if it has above 3.5 and below 5 star rating, �Average� if it is above 3
-- and below 3.5 and �Bad� if it is below 3 star rating '''

SELECT 
    CASE
        WHEN Rating > 4 THEN 'Excellent'
        WHEN Rating > 3.5 AND Rating <= 4 THEN 'Good'
        WHEN Rating > 3 AND Rating <= 3.5 THEN 'Average'
        ELSE 'Bad'
    END AS Rating_Status
FROM jomato;

-- 4. Find the Ceil, floor and absolute values of the rating column and display the current date
-- and separately display the year,month_name and day.

select ceil(Rating),floor(Rating),abs(Rating),current_date() as currentDate ,
Year(current_date()) , monthname(current_date()) as month_name , day(current_date())
from jomato;

-- 5. Display the restaurant type and total average cost using rollup.

select RestaurantType,avg(AverageCost)
from jomato
group by RestaurantType with rollup;


 