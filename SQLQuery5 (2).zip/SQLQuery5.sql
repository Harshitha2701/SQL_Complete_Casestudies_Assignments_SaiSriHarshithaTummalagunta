------------ Case study: 2  By Sai Sri Harshitha Tummalagunta ------ 

create database casestudy2 

--------------------------------
use casestudy2 
---------------------------------


--- Create a table Location 

create table location(Location_ID int, city varchar(255));  

-- now let's put the values inside the table i.e; insert the record/rows

-- Step 1: Create the LOCATIONN table
CREATE TABLE Locationn (
    Location_ID INT PRIMARY KEY,
    City NVARCHAR(100)
);

-- Step 2: Insert data into the LOCATIONN table
INSERT INTO LOCATIONN (Location_ID, City) VALUES (122, 'New York');
INSERT INTO LOCATIONN (Location_ID, City) VALUES (123, 'Dallas');
INSERT INTO LOCATIONN (Location_ID, City) VALUES (124, 'Chicago');
INSERT INTO LOCATIONN (Location_ID, City) VALUES (167, 'Boston'); 



------ Create the DEPARTMENT table
CREATE TABLE DEPARTMENT (
    Department_ID INT PRIMARY KEY,
    Name NVARCHAR(100),
    Location_ID INT,
    FOREIGN KEY (Location_ID) REFERENCES LOCATIONN(Location_ID)
);

-- Insert data into the DEPARTMENT table
INSERT INTO DEPARTMENT (Department_ID, Name, Location_ID) VALUES (10, 'Accounting', 122);
INSERT INTO DEPARTMENT (Department_ID, Name, Location_ID) VALUES (20, 'Sales', 124);
INSERT INTO DEPARTMENT (Department_ID, Name, Location_ID) VALUES (30, 'Research', 123);
INSERT INTO DEPARTMENT (Department_ID, Name, Location_ID) VALUES (40, 'Operations', 167);

---- Creating Job Table 
-- Step 1: Create the JOB table
CREATE TABLE JOB (
    Job_ID INT PRIMARY KEY,
    Designation NVARCHAR(100)
);

-- Step 2: Insert data into the JOB table
INSERT INTO JOB (Job_ID, Designation) VALUES (667, 'Clerk');
INSERT INTO JOB (Job_ID, Designation) VALUES (668, 'Staff');
INSERT INTO JOB (Job_ID, Designation) VALUES (669, 'Analyst');
INSERT INTO JOB (Job_ID, Designation) VALUES (670, 'Sales Person');
INSERT INTO JOB (Job_ID, Designation) VALUES (671, 'Manager');
INSERT INTO JOB (Job_ID, Designation) VALUES (672, 'President');





----- Creating employee table
CREATE TABLE EMPLOYEE (
    e_Id INT PRIMARY KEY,
    Last_Name NVARCHAR(100),
    First_Name NVARCHAR(100),
    Middle_Name NVARCHAR(100),
    Job_Id INT,
    Hire_Date DATE,
    Salary DECIMAL(10,2),
    Comm DECIMAL(10,2),
    Department_Id INT,
    FOREIGN KEY (Job_Id) REFERENCES JOB(Job_ID),
    FOREIGN KEY (Department_Id) REFERENCES DEPARTMENT(Department_ID)
);

-- Insert data into the EMPLOYEE table
INSERT INTO EMPLOYEE (e_Id, Last_Name, First_Name, Middle_Name, Job_Id, Hire_Date, Salary, Comm, Department_Id) 
VALUES 
(7369, 'Smith', 'John', 'Q', 667, '1984-12-17', 800, NULL, 20),
(7499, 'Allen', 'Kevin', 'J', 670, '1985-02-20', 1600, 300, 30),
(755, 'Doyle', 'Jean', 'K', 671, '1985-04-04', 2850, NULL, 30),
(756, 'Dennis', 'Lynn', 'S', 671, '1985-05-15', 2750, NULL, 30),
(757, 'Baker', 'Leslie', 'D', 671, '1985-06-10', 2200, NULL, 40),
(7521, 'Wark', 'Cynthia', 'D', 670, '1985-02-22', 1250, 50, 30);  



----- Now let's display the created tables 
select * from locationn 

select * from department 

select * from job 

select * from employee 



------- Simple Questions 

--1. List all the employee details. 

select * from employee 

--2. List all the department details.   

select * from department 

--3.List all job details. 

select * from job 

--4. List all the locations. 

select * from locationn 


--5. List out the First Name, Last Name, Salary, Commission for all Employees

SELECT First_Name, Last_Name, Salary, Comm
FROM EMPLOYEE; 


--6.List out the Employee ID, Last Name, Department ID for all employees and 
--alias 
--Employee ID as "ID of the Employee", Last Name as "Name of the 
--Employee", Department ID as "Dep_id".



SELECT e_Id AS "ID of the Employee", Last_Name AS "Name of the Employee", Department_Id AS "Dep_id"
FROM EMPLOYEE;



--7.List out the annual salary of the employees with their names only.

SELECT First_Name, Last_Name, (Salary * 12) AS Annual_Salary
FROM EMPLOYEE;




--- WHERE Condition


--1.. List the details about "Smith".
SELECT *
FROM EMPLOYEE
WHERE Last_Name = 'Smith';  

--2.  List out the employees who are working in department 20. 

select * from employee 
-----------------------
select * 
from employee 
where department_id = 20  

--3.List out the employees who are earning salary between 2000 and 3000


select * from employee 
where salary between 2000 and 3000 


-- 4.List out the employees who are working in department 10 or 20

SELECT *
FROM EMPLOYEE
WHERE Department_Id IN (10, 20); 

--5.  Find out the employees who are not working in department 10 or 30. 

select * from employee 
where department_id not in (10,30) 

--6. List out the employees whose name starts with 'L'. 


select * from employee 
where First_name like'L%'  


--7.List out the employees whose name starts with 'L' and ends with 'E'. 

SELECT *
FROM EMPLOYEE
WHERE First_Name LIKE 'L%E'; 

--8.List out the employees whose name length is 4 and start with 'J'. 

SELECT *
FROM EMPLOYEE
WHERE First_Name LIKE 'J___';

--9.List out the employees who are working in department 30 and draw the salaries more than 2500.
SELECT *
FROM EMPLOYEE
WHERE Department_Id = 30 AND Salary > 2500;

--10.List out the employees who are not receiving commission.
SELECT *
FROM EMPLOYEE
WHERE Comm IS NULL; 



---------ORDER BY Clause 

--1. List out the Employee ID and Last Name in ascending order based on the Employee ID.

SELECT e_Id AS "Employee ID", Last_Name
FROM EMPLOYEE
ORDER BY e_Id ASC;

--2.List out the Employee ID and Name in descending order based on salary.

SELECT e_Id AS "Employee ID", CONCAT(First_Name, ' ', Last_Name) AS "Name"
FROM EMPLOYEE
ORDER BY Salary DESC;

--3.List out the employee details according to their Last Name in ascending order

FROM EMPLOYEE
ORDER BY Last_Name ASC;

--4.list out the employee details according to their Last Name in ascending order and then Department ID in descending order

SELECT *
FROM EMPLOYEE
ORDER BY Last_Name ASC, Department_Id DESC;




---- Group By and Having Clause 

--1. List out the department wise maximum salary, minimum salary and average salary of the employees. 
SELECT 
    Department_Id,
    MAX(Salary) AS Max_Salary,
    MIN(Salary) AS Min_Salary,
    AVG(Salary) AS Avg_Salary
FROM 
    EMPLOYEE
GROUP BY 
    Department_Id
HAVING 
    COUNT(*) > 0;
	

--2. List out the job wise maximum salary, minimum salary, and average salary of the employees.
SELECT e_Id AS "Employee ID", CONCAT(First_Name, ' ', Last_Name) AS "Name"
FROM EMPLOYEE
ORDER BY Salary DESC;


--3.List out the number of employees who joined each month in ascending order.

SELECT *
FROM EMPLOYEE
ORDER BY Last_Name ASC;


--4. List out the number of employees for each month and year in ascending order based on the year and month.

SELECT *
FROM EMPLOYEE
ORDER BY Last_Name ASC, Department_Id DESC;



--5. List out the Department ID having at least four employees.
SELECT 
    Department_Id,
    COUNT(*) AS Num_Employees
FROM 
    EMPLOYEE
GROUP BY 
    Department_Id
HAVING 
    COUNT(*) >= 4;




--6.How many employees joined in February month.
SELECT MONTH(Hire_Date) AS Join_Month, COUNT(*) AS Num_Employees
FROM EMPLOYEE
GROUP BY Hire_date
HAVING Hire_date = 2;

select * from employee 

--7. How many employees joined in May or June month. 

SELECT 
    MONTH(Hire_Date) AS Join_Month, 
    COUNT(*) AS Num_Employees
FROM 
    EMPLOYEE
WHERE 
    MONTH(Hire_Date) IN (5, 6)
GROUP BY 
   Hire_date 

--8. How many employees joined in 1985?
SELECT 
    COUNT(*) AS Num_Employees
FROM 
    EMPLOYEE
WHERE 
    Hire_Date LIKE '1985%';

--9. How many employees joined each month in 1985?

SELECT 
    MONTH(Hire_Date) AS Join_Month,
    COUNT(*) AS Num_Employees
FROM 
    EMPLOYEE
WHERE 
    YEAR(Hire_Date) = 1985
GROUP BY 
    MONTH(Hire_Date);


--10. How many employees were joined in April 1985?
SELECT 
    COUNT(*) AS Num_Employees_April_1985
FROM 
    EMPLOYEE
WHERE 
    MONTH(Hire_Date) = 4
    AND YEAR(Hire_Date) = 1985;


--11. Which is the Department ID having greater than or equal to 3 employees joining in April 1985? 

SELECT Department_Id
FROM EMPLOYEE
WHERE YEAR(Hire_Date) = 1985
    AND MONTH(Hire_Date) = 4
GROUP BY Department_Id
HAVING COUNT(*) >= 3;





---- JOINS 


select * from department 

select * from employee 

select * from locationn   

--1. List out employees with their department names.

SELECT e.Last_Name, e.First_Name, d.Name AS Department_Name
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID;



--2.Display employees with their designations. 

SELECT e.Last_Name, e.First_Name, j.Designation
FROM EMPLOYEE e
JOIN JOB j ON e.Job_ID = j.Job_ID;


--3.Display the employees with their department names and city. 

SELECT e.Last_Name, e.First_Name, d.Name AS Department_Name, l.City
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
JOIN LOCATION l ON d.Location_ID = l.Location_ID;


--4.How many employees are working in different departments? Display with department names. 

SELECT d.Name AS Department_Name, COUNT(*) AS Employee_Count
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
GROUP BY d.Name;




--5. How many employees are working in the sales department?

SELECT COUNT(*) AS Sales_Employee_Count
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
WHERE d.Name = 'Sales';

--6. Which is the department having greater than or equal to 3 employees and display the department names in ascending order
SELECT d.Name AS Department_Name, COUNT(*) AS Employee_Count
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
GROUP BY d.Name
HAVING COUNT(*) >= 3
ORDER BY Department_Name ASC;

--7. How many employees are working in 'Dallas'?

SELECT COUNT(*) AS Dallas_Employee_Count
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
JOIN LOCATION l ON d.Location_ID = l.Location_ID
WHERE l.City = 'Dallas';


select * from employee 
select * from locationn
select * from department 


--8. Display all employees in sales or operation departments 

SELECT e.Last_Name, e.First_Name, d.Name AS Department_Name
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
WHERE d.Name IN ('Sales', 'Operations');


----- CONDITIONAL STATEMENTS 

--1. Display the employee details with salary grades. Use conditional statement to create a grade column. 
SELECT 
    e.e_Id,
    e.Last_Name,
    e.First_Name,
    e.Salary,
    CASE 
        WHEN e.Salary >= 1000 AND e.Salary < 2000 THEN 'Grade A'
        WHEN e.Salary >= 2000 AND e.Salary < 3000 THEN 'Grade B'
        WHEN e.Salary >= 3000 AND e.Salary < 4000 THEN 'Grade C'
        ELSE 'Grade D'
    END AS Salary_Grade
FROM 
    EMPLOYEE e;



--2.List out the number of employees grade wise. Use conditional statement to 
create a grade column. 

SELECT 
    CASE 
        WHEN Salary >= 1000 AND Salary < 2000 THEN 'Grade A'
        WHEN Salary >= 2000 AND Salary < 3000 THEN 'Grade B'
        WHEN Salary >= 3000 AND Salary < 4000 THEN 'Grade C'
        ELSE 'Grade D'
    END AS Salary_Grade,
    COUNT(*) AS Employee_Count
FROM EMPLOYEE
GROUP BY Salary_Grade;


--3. . Display the "employee salary grades" and the "number of employees" between 2000 to 5000 range of salary.

SELECT 
    CASE 
        WHEN Salary >= 1000 AND Salary < 2000 THEN 'Grade A'
        WHEN Salary >= 2000 AND Salary < 3000 THEN 'Grade B'
        WHEN Salary >= 3000 AND Salary < 4000 THEN 'Grade C'
        ELSE 'Grade D'
    END AS Salary,
    COUNT(*) AS Employee_Count
FROM EMPLOYEE
GROUP BY Salary;



------ SUBQUERIES 

--1.Display the employees list who got the maximum salary.  

SELECT e_ID, Last_Name, First_Name, Salary
FROM EMPLOYEE
WHERE Salary = (SELECT MAX(Salary) FROM EMPLOYEE);


--2.Display the employees who are working in the sales department. 
SELECT e_ID, Last_Name, First_Name, Salary
FROM EMPLOYEE
WHERE Salary = (SELECT MAX(Salary) FROM EMPLOYEE);


--3. Display the employees who are working as 'Clerk'. 
SELECT *
FROM EMPLOYEE
WHERE Job_ID = (SELECT Job_ID FROM JOB WHERE Designation = 'Clerk');


 --4.Display the list of employees who are living in 'Boston'.  

SELECT e.*
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
JOIN LOCATION l ON d.Location_ID = l.Location_ID
WHERE l.City = 'Boston';


 --5.Find out the number of employees working in the sales department.

SELECT COUNT(*) AS Sales_Employee_Count
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Department_ID = d.Department_ID
WHERE d.Name = 'Sales';


select * from employee 

select * from department 

 --6.Update the salaries of employees who are working as clerks on the basis of 10%.

UPDATE EMPLOYEE
SET Salary = Salary * 1.10
WHERE Job_ID = (SELECT Job_ID FROM JOB WHERE Designation = 'Clerk');

select * from employee 


 --7. Display the second highest salary drawing employee details.

 SELECT *
FROM EMPLOYEE
WHERE Salary = (
    SELECT MAX(Salary)
    FROM EMPLOYEE
    WHERE Salary < (
        SELECT MAX(Salary)
        FROM EMPLOYEE
    )
);


 --8. List out the employees who earn more than every employee in department 30.
 SELECT *
FROM EMPLOYEE
WHERE Salary > ALL (
    SELECT Salary
    FROM EMPLOYEE
    WHERE Department_ID = 30
);


 --9. Find out which department has no employees. 

 SELECT d.*
FROM DEPARTMENT d
LEFT JOIN EMPLOYEE e ON d.Department_ID = e.Department_ID
WHERE e.e_ID IS NULL;


--10.Find out the employees who earn greater than the average salary for their department.
SELECT e.*
FROM EMPLOYEE e
JOIN (
    SELECT Department_ID, AVG(Salary) AS Avg_Salary
    FROM EMPLOYEE
    GROUP BY Department_ID
) AS dept_avg ON e.Department_ID = dept_avg.Department_ID
WHERE e.Salary > dept_avg.Avg_Salary;










select * from employee 
select * from job 
select * from locationn 
select * from  department 