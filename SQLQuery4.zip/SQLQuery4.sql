---- Assignment 3:  By Sai Sri Harshitha Tummalagunta---- 


--1.  Create a stored procedure to display the restaurant name, type and cuisine where the table booking is not zero. 

-- Note here  "sp" means stored procedure 

create  procedure sp_jomato as
begin
select RestaurantName,RestaurantType , CuisinesType , TableBooking from Jomato
where TableBooking !=0end;-- executing our store procedure exec sp_jomato;  


--2. Create a transaction and update the cuisine type �Cafe� to �Cafeteria�. Check the result and rollback it.

BEGIN TRANSACTION;

UPDATE Jomato
SET CuisinesType = 'Cafeteria'
WHERE CuisinesType = 'Cafe';

-- Check the result
SELECT * FROM jomato WHERE CuisinesType = 'Cafeteria';

-- If the result is incorrect/ do you want to undo it, rollback the transaction
 ROLLBACK;
-- If the result is correct and if you want to procedure, commit the transaction
 COMMIT;


 select * from jomato 


 --3.  Generate a "row number" column and find the top 5 areas with the highest rating of restaurants 

select distinct top 5 ROW_NUMBER() over (order by rating desc) as RowNumber ,Area ,  Rating from Jomato


--4. Use the while loop to display the 1 to 50.

DECLARE @i INT = 1;
WHILE @i <= 50
BEGIN
    PRINT @i;
    SET @i = @i + 1;
END;


--5. Write a query to Create a "Top rating view to store the generated top 5 highest rating of restaurants.

CREATE VIEW Top_Rating AS
SELECT TOP (5) RestaurantName, Rating
FROM jomato
ORDER BY Rating DESC; 


select * from jomato     


--6. Write a trigger that sends an email notification to the restaurant owner whenever a new record is inserted.create trigger Trigger_Message on jomatoafter insertasbegin	select 'A new record has been inserted 'end;insert into jomato( restaurantName , RestaurantType , Rating ,Area)values('Harshysgalaxy', 'cafe', 5,'Hyderabad')select * from jomato










